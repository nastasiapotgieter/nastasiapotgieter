// Add event listener for the "Shop Now" button
document.querySelector("#shop-now").addEventListener("click", function() {
    alert("Welcome to the Huudini shop!");
});